
<?php
session_start();


session_destroy();
header("refresh:1;url=main.html");



?>
<html
<section class="site-cover" style="background-image: url(images/bg_3.jpg);" id="section-home">

/>